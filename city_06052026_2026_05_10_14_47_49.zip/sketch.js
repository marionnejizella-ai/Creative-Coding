let skyscrapers = [];
let apartments = [];
let factories = [];
let trees = [];
let mountains = [];

function setup() {
  createCanvas(900, 550);
  generateScene();
}

function draw() {
  drawSky();
  drawMountains();
  drawGround();

  // City layers
  drawFactories();
  drawApartments();
  drawSkyscrapers();

  drawTrees();
}

// =====================================
// GENERATE SCENE
// =====================================
function generateScene() {

  skyscrapers = [];
  apartments = [];
  factories = [];
  trees = [];
  mountains = [];

  // Skyscrapers
  for (let i = 50; i < width; i += random(90, 130)) {
    skyscrapers.push({
      x: i,
      w: random(60, 90),
      h: random(220, 380),
      color: color(random(80, 180), random(80, 180), random(120, 220))
    });
  }

  // Apartment blocks
  for (let i = 20; i < width; i += random(120, 170)) {
    apartments.push({
      x: i,
      w: random(90, 130),
      h: random(120, 220),
      color: color(random(150, 220), random(120, 180), random(120, 180))
    });
  }

  // Industrial factories
  for (let i = 0; i < width; i += random(180, 250)) {
    factories.push({
      x: i,
      w: random(130, 180),
      h: random(70, 120),
      smokeOffset: random(10, 40)
    });
  }

  // Trees
  for (let i = 0; i < 15; i++) {
    trees.push({
      x: random(width),
      y: height - 70,
      size: random(30, 55)
    });
  }

  // Mountains
  for (let i = 0; i < width; i += 120) {
    mountains.push({
      x: i,
      h: random(120, 220)
    });
  }
}

// =====================================
// SKY
// =====================================
function drawSky() {

  for (let y = 0; y < height; y++) {

    let c = lerpColor(
      color(100, 180, 255),
      color(255, 190, 150),
      y / height
    );

    stroke(c);
    line(0, y, width, y);
  }
}

// =====================================
// MOUNTAINS
// =====================================
function drawMountains() {

  fill(120, 120, 130);
  noStroke();

  for (let m of mountains) {

    triangle(
      m.x,
      height - 120,

      m.x + 120,
      height - 120,

      m.x + 60,
      height - 120 - m.h
    );
  }
}

// =====================================
// CITY LAND / GROUND
// =====================================
function drawGround() {

  // Grass layer
  fill(60, 170, 80);
  rect(0, height - 100, width, 100);

  // Road layer
  fill(70);
  rect(0, height - 70, width, 40);

  // Road lines
  stroke(255, 255, 0);
  strokeWeight(4);

  for (let i = 0; i < width; i += 40) {
    line(i, height - 50, i + 20, height - 50);
  }
}

// =====================================
// SKYSCRAPERS
// =====================================
function drawSkyscrapers() {

  for (let b of skyscrapers) {

    fill(b.color);
    noStroke();

    rect(b.x, height - 100 - b.h, b.w, b.h);

    // Windows
    fill(255, 255, 180);

    for (
      let y = height - 100 - b.h + 15;
      y < height - 120;
      y += 22
    ) {

      for (
        let x = b.x + 8;
        x < b.x + b.w - 10;
        x += 18
      ) {

        rect(x, y, 10, 12);
      }
    }
  }
}

// =====================================
// APARTMENT BLOCKS
// =====================================
function drawApartments() {

  for (let a of apartments) {

    fill(a.color);
    noStroke();

    rect(a.x, height - 100 - a.h, a.w, a.h);

    // Balconies / windows
    fill(230);

    for (
      let y = height - 100 - a.h + 12;
      y < height - 115;
      y += 25
    ) {

      for (
        let x = a.x + 10;
        x < a.x + a.w - 15;
        x += 25
      ) {

        rect(x, y, 15, 10);
      }
    }
  }
}

// =====================================
// FACTORIES
// =====================================
function drawFactories() {

  for (let f of factories) {

    // Factory body
    fill(140);
    rect(f.x, height - 100 - f.h, f.w, f.h);

    // Roof
    fill(110);

    triangle(
      f.x,
      height - 100 - f.h,

      f.x + 30,
      height - 130 - f.h,

      f.x + 60,
      height - 100 - f.h
    );

    triangle(
      f.x + 60,
      height - 100 - f.h,

      f.x + 90,
      height - 130 - f.h,

      f.x + 120,
      height - 100 - f.h
    );

    // Chimney
    fill(90);

    rect(
      f.x + f.w - 40,
      height - 180 - f.h,
      25,
      80
    );

    // Smoke
    noStroke();
    fill(180, 180, 180, 150);

    ellipse(
      f.x + f.w - 25,
      height - 190 - f.h - sin(frameCount * 2) * 10,
      35
    );

    ellipse(
      f.x + f.w - 5,
      height - 220 - f.h - sin(frameCount * 2) * 10,
      45
    );
  }
}

// =====================================
// TREES
// =====================================
function drawTrees() {

  for (let t of trees) {

    // Trunk
    fill(100, 50, 0);
    rect(t.x, t.y, 10, 25);

    // Leaves
    fill(34, 139, 34);
    ellipse(t.x + 5, t.y - 10, t.size);
  }
}

// =====================================
// CLICK TO REGENERATE CITY
// =====================================
function mousePressed() {
  generateScene();
}