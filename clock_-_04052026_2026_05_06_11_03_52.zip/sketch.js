let hearts = [];

function setup() {
  createCanvas(400, 400);
  angleMode(DEGREES);
}

function draw() {
  let hr = hour();
  let isNight = (hr >= 18 || hr < 6);

  // Background (Day/Night mode)
  if (isNight) {
    background(184, 44, 115); // dark purple night
  } else {
    background(255, 135, 194); // pink day
  }

  translate(width / 2, height / 2);

  // Floating hearts
  drawHearts();

  // Clock face
  if (isNight) {
    fill(255, 184, 220);
    stroke(255, 105, 180);
  } else {
    fill(255, 240, 245);
    stroke(255, 105, 180);
  }

  strokeWeight(4);
  ellipse(0, 0, 300, 300);

  let mn = minute();
  let sc = second();

  // Smooth animation
  let scAngle = map(sc + millis()/1000, 0, 60, 0, 360);
  let mnAngle = map(mn + sc/60, 0, 60, 0, 360);
  let hrAngle = map(hr % 12 + mn/60, 0, 12, 0, 360);

  // Seconds hand
  push();
  rotate(scAngle);
  stroke(255, 20, 147);
  strokeWeight(2);
  line(0, 0, 0, -120);
  pop();

  // Minutes hand
  push();
  rotate(mnAngle);
  stroke(255, 105, 180);
  strokeWeight(4);
  line(0, 0, 0, -100);
  pop();

  // Hours hand
  push();
  rotate(hrAngle);
  stroke(199, 21, 133);
  strokeWeight(6);
  line(0, 0, 0, -70);
  pop();

  // Center
  fill(255, 20, 147);
  noStroke();
  ellipse(0, 0, 12, 12);

  // Numbers
  fill(255, 105, 180);
  noStroke();
  textAlign(CENTER, CENTER);
  textSize(20);

  for (let i = 1; i <= 12; i++) {
    let angle = map(i, 0, 12, 0, 360) - 90;
    let x = 110 * cos(angle);
    let y = 110 * sin(angle);
    text(i, x, y);
  }
}

// HEART SYSTEM 💖
function drawHearts() {
  // add new hearts randomly
  if (random(1) < 0.05) {
    hearts.push({
      x: random(-200, 200),
      y: 200,
      size: random(10, 20),
      speed: random(1, 2)
    });
  }

  for (let i = hearts.length - 1; i >= 0; i--) {
    let h = hearts[i];

    fill(255, 105, 180, 180);
    noStroke();
    drawHeart(h.x, h.y, h.size);

    h.y -= h.speed;

    // remove if off screen
    if (h.y < -200) {
      hearts.splice(i, 1);
    }
  }
}

// Heart shape
function drawHeart(x, y, s) {
  push();
  translate(x, y);
  scale(s / 20);
  beginShape();
  vertex(0, 0);
  bezierVertex(-10, -10, -20, 10, 0, 20);
  bezierVertex(20, 10, 10, -10, 0, 0);
  endShape(CLOSE);
  pop();
}