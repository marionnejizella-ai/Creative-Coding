let markerX;
let speed = 15;
let gameOver = false;
let winner = "";

function setup() {
  createCanvas(800, 400);
  markerX = width / 2;
}

function draw() {
  background(30);
  
  // Draw center line
  stroke(255);
  line(width / 2, 0, width / 2, height);
  
  // Draw goals
  noStroke();
  fill(0, 100, 255);
  rect(0, 0, 50, height); // Player 1 goal(left)
  
  fill (255, 100, 100);
  rect(width - 50, 0, 50, height); // Player 2 goal(right)
  
  // Draw marker
  fill(255);
  ellipse(markerX, height / 2, 40);
  
  // Instructions
  textSize(16);
  fill(255);
  textAlign(CENTER)
  text("Player 1: Press 'A' | Player 2: Press 'L'", width / 2, 30);
  
  // Win state
  if (gameOver) {
    textSize(40);
    fill(255, 255, 0);
    text(winner + "Wins!", width / 2, height / 2);
    
    textSize(16);
    text("Press R to Restart", width / 2, height / 2 + 40);
  }

  checkWin();
}

function keyPressed() {
  if (!gameOver) {
    if (key === 'a' || key === 'A') {
      markerX -= speed; // Player 1 pushes left
    }
    if (key === 'l' || key === 'L') {
      markerX += speed; // Player 2 pushes right
    }
  }
  
  // Restart game
  if (gameOver && (key === 'r' || key === 'R')) {
    markerX = width / 2;
    gameOver = false;
    winner = "";
  }
}

function checkWin() {
  if (markerX <= 50) {
    gameOver = true;
    winner = "Player 1";
  }
  if (markerX >= width - 50) {
    gameOver = true;
    winner = "Player 2";
  }
}